import React from "react";
import Letter from "./Letter/Letter";
import { boardWordle } from "./Words/Words";
export default function Board() {
  console.log(boardWordle);
  return (
    <div className="board">
      {boardWordle.map((input, index) => {
        // console.log(index);
        return (
          <div className="row">
            {input.map((subItem, sIndex) => {
              // console.log("SubIndex", sIndex);
              return <Letter letterPos={sIndex} attemptValue={index} />;
            })}
          </div>
        );
      })}
    </div>
  );
}
