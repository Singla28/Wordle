import React, { useContext } from "react";
import { AppContext } from "../../App";

export default function Key(props) {
  const { keyVal, disabled, almost, correct } = props;
  const { gameOver, setGameOver, onSelectLetter, onEnter, onDelete } =
    useContext(AppContext);

  const selectLetter = () => {
    if (gameOver.gameOver) return;
    keyVal === "ENTER"
      ? onEnter()
      : keyVal === "DEL"
      ? onDelete()
      : onSelectLetter(keyVal);
  };
  return (
    <div
      className="key"
      onClick={selectLetter}
      id={
        disabled
          ? "disabled"
          : almost
          ? "almostLetter"
          : correct
          ? "correctLetter"
          : ""
      }
    >
      {keyVal}
    </div>
  );
}
