import React, { useCallback, useContext, useEffect } from "react";
import { AppContext } from "../../App";
import Key from "./Key";

export default function KeyBoard() {
  const keys = [
    ["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"],
    ["A", "S", "D", "F", "G", "H", "J", "K", "L"],
    ["ENTER", "Z", "X", "C", "V", "B", "N", "M", "DEL"],
  ];

  const {
    currentAttempt,
    disabledLetters,
    almostLetters,
    correctLetters,
    gameOver,
    onSelectLetter,
    onEnter,
    onDelete,
  } = useContext(AppContext);

  const handleKeyboard = useCallback(
    (e) => {
      if (gameOver.gameOver) {
        return;
      }
      if (e.key === "ENTER") {
        onEnter();
      } else if (e.key === "DELETE") {
        onDelete();
      } else {
        keys.forEach((key) => {
          if (e.key === key) {
            onSelectLetter(key);
          }
        });
      }
    },
    [currentAttempt]
  );

  useEffect(() => {
    document.addEventListener("keydown", handleKeyboard);
    return () => {
      document.removeEventListener("keydown", handleKeyboard);
    };
  }, [handleKeyboard]);

  return (
    <div className="keyboard" onKeyDown={handleKeyboard}>
      {keys.map((input) => {
        return (
          <div className="row">
            {input.map((value, sIndex) => {
              return (
                <Key
                  // key={sIndex}
                  keyVal={value}
                  disabled={disabledLetters.includes(value)}
                  correct={correctLetters.includes(value)}
                  almost={almostLetters.includes(value)}
                />
              );
            })}
          </div>
        );
      })}
    </div>
  );
}
