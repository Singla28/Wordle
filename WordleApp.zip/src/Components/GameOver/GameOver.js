import React from "react";

export default function GameOver() {
  return <div></div>;
}
