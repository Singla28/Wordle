import React, { useContext, useEffect } from "react";
import { AppContext } from "../../App";

const Letter = (props) => {
  const {
    board,
    correctWord,
    setCorrectWord,
    currentAttempt,
    setCurrentAttempt,
    disabledLetters,
    setDisabledLetters,
    almostLetters,
    setAlmostLetters,
    correctLetters,
    setCorrectLetters,
    gameOver,
    setGameOver,
    onSelectLetter,
    onEnter,
    onDelete,
  } = useContext(AppContext);

  const { letterPos, attemptValue } = props;

  const letter = board[attemptValue][letterPos];
  const correct = correctWord[letterPos] === letter;
  const almost = !correct && letter !== "" && correctWord.includes(letter);

  const letterState =
    currentAttempt.attempt > attemptValue &&
    (correct ? "correct" : almost ? "almost" : "error");

  useEffect(() => {
    if (letter !== "" && !correct && !almost) {
      setDisabledLetters((prev) => [...prev, letter]);
    }
    if (almost) {
      setAlmostLetters((prev) => [...prev, letter]);
    }
    if (correct) {
      setCorrectLetters((prev) => [...prev, letter]);
    }
  }, [currentAttempt.attempt]);
  return (
    <div className="letter" id={letterState ? letterState : ""}>
      {letter}
    </div>
  );
};

export default Letter;
