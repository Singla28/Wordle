import { createContext, useEffect, useState } from "react";
import "./App.css";
import Board from "./Components/Board";
import { boardWordle, generateWords } from "./Components/Words/Words";
import KeyBoard from "./Components/KeyBoard/KeyBoard";
import GameOver from "./Components/GameOver/GameOver";

export const AppContext = createContext();

function App() {
  const [board, setBoard] = useState(boardWordle);
  const [wordSet, setWordSet] = useState(new Set());
  const [correctWord, setCorrectWord] = useState("");
  const [currentAttempt, setCurrentAttempt] = useState({
    attempt: 0,
    letterPos: 0,
  });
  const [gameOver, setGameOver] = useState({
    gameOver: false,
    guessWord: false,
  });
  const [disabledLetters, setDisabledLetters] = useState([]);
  const [almostLetters, setAlmostLetters] = useState([]);
  const [correctLetters, setCorrectLetters] = useState([]);

  useEffect(() => {
    generateWords().then((words) => {
      //console.log(words)
      setWordSet(words.wordSet);
      setCorrectWord(words.todaysWord);
    });
  }, []);

  console.log(correctWord);

  const onSelectLetter = (keyVal) => {
    if (currentAttempt.letterPos > 4 || currentAttempt.attempt === 5) return;
    const newBoard = [...board];
    newBoard[currentAttempt.attempt][currentAttempt.letterPos] = keyVal;
    setBoard(newBoard);
    setCurrentAttempt({
      attempt: currentAttempt.attempt,
      letterPos: currentAttempt.letterPos + 1,
    });
  };

  const onEnter = () => {
    // console.log(currentAttempt.attempt);
    if (currentAttempt.letterPos === 0) return;
    let currWord = "";
    for (let i = 0; i < currentAttempt.letterPos; i++) {
      currWord += board[currentAttempt.attempt][i];
    }

    if (wordSet.has(currWord)) {
      setCurrentAttempt({ attempt: currentAttempt.attempt + 1, letterPos: 0 });
    }
    if (!wordSet.has(currWord) && currentAttempt.attempt !== 4) {
      alert("Word not in the list");
      setCurrentAttempt({ attempt: currentAttempt.attempt + 1, letterPos: 0 });
    }

    if (currWord === correctWord) {
      alert("Congratulations, You Won!");
      setGameOver({ gameOver: true, guessWord: true });
    }
    if (currentAttempt.attempt === 4) {
      alert("Game Over");
      setGameOver({ gameOver: true, guessWord: false });
    }
  };

  const onDelete = () => {
    if (currentAttempt.letterPos === 0) return;

    const newBoard = [...board];
    newBoard[currentAttempt.attempt][currentAttempt.letterPos - 1] = "";
    setBoard(newBoard);
    setCurrentAttempt({
      ...currentAttempt,
      letterPos: currentAttempt.letterPos - 1,
    });
  };

  return (
    <nav className="App">
      <>
        <h1>WORDLE</h1>
        <AppContext.Provider
          value={{
            board,
            setBoard,
            wordSet,
            setWordSet,
            correctWord,
            setCorrectWord,
            currentAttempt,
            setCurrentAttempt,
            disabledLetters,
            setDisabledLetters,
            almostLetters,
            setAlmostLetters,
            correctLetters,
            setCorrectLetters,
            gameOver,
            setGameOver,
            onSelectLetter,
            onEnter,
            onDelete,
          }}
        >
          <div className="game">
            <Board />
            {gameOver.gameOver ? <GameOver /> : <KeyBoard />}
          </div>
        </AppContext.Provider>
      </>
    </nav>
  );
}

export default App;
